"use client"

import type { ReactNode } from "react"
import { motion } from "framer-motion"

interface FeatureCardProps {
  icon: ReactNode
  title: string
  description: string
}

export function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <motion.div
      className="feature-card bg-gray-900/50 border border-gray-800 rounded-xl p-6 hover:border-cyan-500/30 transition-colors duration-300"
      whileHover={{ y: -5, transition: { duration: 0.3 } }}
    >
      <div className="text-cyan-400 mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </motion.div>
  )
}
