"use client"

import { useEffect, useState, useRef } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { useTheme } from "@/context/theme-context"

export default function HeroSection() {
  const [scale, setScale] = useState(1)
  const [isPlaying, setIsPlaying] = useState(true)
  const videoContainerRef = useRef<HTMLDivElement>(null)
  const heroRef = useRef<HTMLDivElement>(null)
  const maxScale = 1.5 // Maximum zoom level
  const { theme } = useTheme()

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY
      const windowHeight = window.innerHeight

      // Calculate scale based on scroll position
      // We'll scale from 1 to maxScale over the first 100vh of scrolling
      const newScale = Math.min(maxScale, 1 + (scrollPosition / windowHeight) * (maxScale - 1))

      setScale(newScale)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying)
    const iframe = document.querySelector<HTMLIFrameElement>(".youtube-video iframe")
    if (iframe && iframe.contentWindow) {
      if (isPlaying) {
        iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', "*")
      } else {
        iframe.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', "*")
      }
    }
  }

  return (
    <div ref={heroRef} className="relative h-screen w-full overflow-hidden">
      {/* Fixed hero content */}
      <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-white p-4">
        <div className="text-center max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex justify-center mb-8"
          >
            <Image src="/logo.png" alt="CapZ Logo" width={400} height={120} priority className="max-w-full h-auto" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-500 to-orange-500"
          >
            Connecting Visionaries with Capital
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="text-lg md:text-xl mb-10 max-w-3xl mx-auto text-white"
          >
            The platform where groundbreaking startups meet strategic investors. We're transforming how innovation gets
            funded.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="flex flex-col sm:flex-row justify-center gap-4"
          >
            <Link
              href="/projects"
              className="px-8 py-3 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium text-lg hover:shadow-lg hover:shadow-cyan-500/20 transition-all duration-300 transform hover:-translate-y-1"
            >
              Explore Projects
            </Link>
            <Link
              href="/entrepreneurs/submit"
              className="px-8 py-3 rounded-full bg-transparent border-2 border-white font-medium text-lg hover:border-cyan-500 hover:text-cyan-400 transition-all duration-300 transform hover:-translate-y-1"
            >
              Submit Startup
            </Link>
            <Link
              href="/login"
              className="px-8 py-3 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium text-lg hover:shadow-lg hover:shadow-blue-500/20 transition-all duration-300 transform hover:-translate-y-1"
            >
              Login
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
          >
            <div className="animate-bounce">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-white"
              >
                <path d="M12 5v14M19 12l-7 7-7-7" />
              </svg>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Video background with zoom effect */}
      <div className="absolute inset-0 z-10 bg-black/50"></div>
      <div
        ref={videoContainerRef}
        className="absolute inset-0 z-0 transition-transform duration-100 youtube-video"
        style={{ transform: `scale(${scale})` }}
      >
        <iframe
          width="100%"
          height="100%"
          src="https://www.youtube.com/embed/4cO36g0x5GU?autoplay=1&mute=1&loop=1&playlist=4cO36g0x5GU&controls=0&showinfo=0&rel=0&enablejsapi=1"
          title="Video Background"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="absolute inset-0 w-full h-full object-cover"
        ></iframe>
      </div>

      {/* Video controls */}
      <div className="absolute bottom-4 right-4 z-30">
        <button
          onClick={togglePlayPause}
          className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
        >
          {isPlaying ? (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="6" y="4" width="4" height="16"></rect>
              <rect x="14" y="4" width="4" height="16"></rect>
            </svg>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polygon points="5 3 19 12 5 21 5 3"></polygon>
            </svg>
          )}
        </button>
      </div>
    </div>
  )
}
