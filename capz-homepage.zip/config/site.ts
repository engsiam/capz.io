export const siteConfig = {
  name: "CapZ",
  description:
    "Connecting Visionaries with Capital - The platform where groundbreaking startups meet strategic investors.",
  url: "https://capz.com",
  ogImage: "https://capz.com/og.jpg",
  links: {
    twitter: "https://twitter.com/capz",
    github: "https://github.com/capz",
  },
}
